//
//  ViewControllerVectores.swift
//  +Vector
//
//  Created by alumno on 10/18/17.
//  Copyright © 2017 ITESM. All rights reserved.
//

import UIKit

protocol protocolo_vector {
    func agregar(v: Vector) -> Void
    func editar(v: Vector) -> Void
}

class ViewControllerVectores: UIViewController {
    var delegado : protocolo_vector!
    var v : Vector!
    var modo : String!

    @IBOutlet weak var txtID: UITextField!
    @IBOutlet weak var txtAngulo: UITextField!
    @IBOutlet weak var txtPIX: UITextField!
    @IBOutlet weak var txtPIY: UITextField!
    @IBOutlet weak var txtMagnitud: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if modo == "editar" {
            title = "Vector " + String(v.id)
            txtID.text = String(v.id)
            txtAngulo.text = String(v.angulo)
            txtPIX.text = String(v.pX)
            txtPIY.text = String(v.pY)
            txtMagnitud.text = String(v.magnitud)
        } else {
            title = "Nuevo Vector"
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func Guardar(_ sender: UIButton) {
        let i = Int(txtID.text!)!
        let x = Double(txtPIX.text!)!
        let y = Double(txtPIY.text!)!
        let a = Double(txtAngulo.text!)!
        let m = Double(txtMagnitud.text!)!
        
        let newVector = Vector(i: i, x: x, y: y, a: a, m: m)
        if modo == "agregar" {
            delegado.agregar(v: newVector)
            navigationController?.popViewController(animated: true)
        }
        else {
            delegado.editar(v: newVector)
            navigationController?.popViewController(animated: true)
        }
    }
}
