//
//  TableViewVectores.swift
//  +Vector
//
//  Created by alumno on 10/18/17.
//  Copyright © 2017 ITESM. All rights reserved.
//

import UIKit

class TableViewVectores: UITableViewController, protocolo_vector {
    var Ej_vectores = Ejercicio()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Vectores"
        tableView.reloadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Ej_vectores.vectores.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "vector", for: indexPath)
        
        cell.textLabel?.text = "Vector " + String(Ej_vectores.vectores[indexPath.row].id)
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vista = segue.destination as! ViewControllerVectores
        vista.modo = segue.identifier
        vista.delegado = self
        
        if segue.identifier == "editar" {
            let index = tableView.indexPathForSelectedRow
            vista.v = Ej_vectores.vectores[index!.row]
        }
    }
    
    func agregar(v: Vector) {
        Ej_vectores.agregarVector(vector: v)
        tableView.reloadData()
    }
    
    func editar(v: Vector) {
        Ej_vectores.editar(vector: v, index: tableView.indexPathForSelectedRow!)
        tableView.reloadData()
    }
    
    /*
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
    }
 
     */
}
