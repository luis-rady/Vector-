//
//  Ejercicio.swift
//  +Vector
//
//  Created by alumno on 10/18/17.
//  Copyright © 2017 ITESM. All rights reserved.
//

import UIKit

class Ejercicio: NSObject {
    var nombre : String!
    var fecha : Date!
    var vectores = [Vector]()
    var suma : Int!
    
    override init() {
        nombre = ""
        suma = 0
    }
    
    init(nombre: String, fecha: Date) {
        self.nombre = nombre
        self.fecha = fecha
    }
    
    func agregarVector(vector: Vector) -> Void {
        vectores.append(vector)
    }
    
    func editar(vector: Vector, index: IndexPath) -> Void {
        vectores[index.row] = vector
    }
}
