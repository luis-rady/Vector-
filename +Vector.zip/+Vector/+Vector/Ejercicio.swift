//
//  Ejercicio.swift
//  +Vector
//
//  Created by alumno on 10/18/17.
//  Copyright © 2017 ITESM. All rights reserved.
//

import UIKit

class Ejercicio: NSObject {
    var nombre : String = ""
    var fecha : Date!
    var vectores = [Vector]()
}
