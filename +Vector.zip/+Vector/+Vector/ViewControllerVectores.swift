//
//  ViewControllerVectores.swift
//  +Vector
//
//  Created by alumno on 10/18/17.
//  Copyright © 2017 ITESM. All rights reserved.
//

import UIKit

protocol vector {
    func agregar(id: Int, compX: Double, compY: Double, angulo: Double) -> Void
    func editar(id: Int, compX: Double, compY: Double, angulo: Double) -> Void
}

class ViewControllerVectores: UIViewController {
    
    var delegado : vector!      // vector es el protocolo
    var v : Vector!             // Vector es la clase
    var modo : String!

    @IBOutlet weak var txtID: UITextField!
    @IBOutlet weak var txtAngulo: UITextField!
    @IBOutlet weak var txtComponenteX: UITextField!
    @IBOutlet weak var txtComponenteY: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if modo == "editar" {
            txtID.text = String(v.id)
            txtAngulo.text = String(v.angulo)
            txtComponenteX.text = String(v.compX)
            txtComponenteY.text = String(v.compY)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func Guardar(_ sender: UIButton) {
        let i = Int(txtID.text!)!
        let x = Double(txtComponenteX.text!)!
        let y = Double(txtComponenteY.text!)!
        let a = Double(txtAngulo.text!)!
        let m = sqrt(Double(pow(x, 2) + pow(y, 2)))
        
        if modo == "agregar" {
            delegado.agregar(id: i, compX: x, compY: y, angulo: a)
        }
        else {
            delegado.editar(id: i, compX: x, compY: y, angulo: a,)
        }
    }
}
