//
//  Vector.swift
//  +Vector
//
//  Created by alumno on 10/18/17.
//  Copyright © 2017 ITESM. All rights reserved.
//

import UIKit

class Vector: NSObject {
    var id : Int = 0
    var compX : Double = 0.0
    var compY : Double = 0.0
    var angulo : Double = 45.0
    var magnitud : Double = 0.0
    
    init(i: Int, x: Double, y: Double, a: Double, m: Double) {
        id = i
        compX = x
        compY = y
        angulo = a
        magnitud = m
    }
}
